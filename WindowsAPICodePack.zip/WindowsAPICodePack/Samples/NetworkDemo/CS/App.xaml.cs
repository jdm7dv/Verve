﻿//Copyright (c) Microsoft Corporation.  All rights reserved.

using System.Windows;

namespace Microsoft.WindowsAPICodePack.Samples.NetworkDemo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
