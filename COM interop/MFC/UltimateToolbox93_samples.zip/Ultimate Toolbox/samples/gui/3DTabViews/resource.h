//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TabViews.rc
//
#define IDR_MAINFRAME                   128
#define IDR_TABVIETYPE                  129
#define ID_DESCRIPTION_FILE             130
#define IDB_IL_TABVIEWS                 131
#define IDD_CUSTOMIZE                   132
#define IDC_LIST_STYLES                 1001
#define IDC_CHECK_VERTICAL              1001
#define IDC_EDIT_OFFSET                 1002
#define IDC_EDIT_OFFSET_EXTERNAL        1002
#define IDC_SPIN_OFFSET                 1003
#define IDC_SPIN_OFFSET_EXTERNAL        1003
#define IDC_EDIT_OFFSET_INTERNAL        1004
#define IDC_SPIN_OFFSET_INTERNAL        1005
#define IDC_CHECK_BOTTOM                1006
#define IDC_CHECK_MULTILINE             1007
#define IDC_CHECK_FIXED_WIDTH           1008
#define IDC_CHECK_SCROLL_OPPOSITE       1009
#define IDC_CHECK_SHOW_CUSTOMIZE_DLG    1010
#define IDC_STATIC_SEPARATOR1           1011
#define IDC_STATIC_SEPARATOR2           1012
#define IDC_STATIC_SEPARATOR3           1013
#define IDC_STATIC_TITLE                1014
#define ID_VIEW_CUSTOMIZE               32771
#define ID_VIEW_SHOW_CUSTOMIZE_DLG      32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
