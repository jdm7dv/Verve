//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BitmapButtonDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_BITMAPBUTTONDEMO_DIALOG     102
#define IDS_ACTION_1                    102
#define IDR_MAINFRAME                   128
#define IDB_TEST_BITMAP                 129
#define ID_DESCRIPTION_FILE             129
#define IDB_TOOL_BITMAP_3               131
#define IDC_CURSOR1                     132
#define IDI_TOOL_ICON_2                 133
#define IDB_TOOL_BITMAP_1               134
#define IDD_HYPER_DLG                   141
#define IDB_SPACE                       142
#define IDB_SUN                         143
#define IDR_AVI_TEST                    150
#define IDI_ICON_TEST                   156
#define IDB_TICK                        157
#define IDC_BUTTON_1                    1000
#define IDC_BUTTON_2                    1001
#define IDC_BUTTON_3                    1002
#define IDC_DISABLED_1                  1003
#define IDC_MULTILINE                   1004
#define IDC_BUTTON_10                   1006
#define IDC_BUTTON_11                   1007
#define IDC_BUTTON_12                   1008
#define IDC_TRACK_LOOK_1                1009
#define IDC_ACTION_1                    1010
#define IDC_TRACK_LOOK_1X               1012
#define IDC_LEFT_TOP                    1013
#define IDC_CENTER_TOP                  1014
#define IDC_RIGHT_TOP                   1015
#define IDC_LEFT_VCENTER                1016
#define IDC_LEFT_BOTTOM                 1017
#define IDC_CENTER_BOTTOM               1018
#define IDC_RIGHT_VCENTER               1019
#define IDC_RIGHT_BOTTOM                1020
#define IDC_CENTER_VCENTER              1021
#define IDC_AUTO_RESIZE_1               1022
#define IDC_TEXT_1                      1023
#define IDC_SET_TEXT                    1024
#define IDC_TEXT_1X                     1025
#define IDC_TOOLTIP_1                   1026
#define IDC_FONT_1                      1027
#define IDC_SET_TOOLTIP                 1028
#define IDC_TOOLTIP                     1029
#define IDC_DISABLED_1X                 1030
#define IDC_HAND_CURSOR                 1031
#define IDC_HYPER_LOOK                  1031
#define IDC_HYPER                       1032
#define IDC_SPACE                       1033
#define IDC_PSEUDO_DISABLE              1037
#define IDC_NEW                         1041
#define IDC_RADIO_DROPDOWN              1044
#define IDC_RADIO_RIGHTDROPDOWN         1045
#define IDC_RADIO_TOGGLE                1046
#define IDC_RADIO_NORMAL                1047
#define IDC_RADIO_TOGGLETHREESTATE      1048
#define IDC_RADIO_NOARROWDROPDOWN       1049
#define IDC_STATIC_HEADER               1050
#define IDC_BUTTON1                     1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
