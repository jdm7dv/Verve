//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ApplicationBar.rc
//
#define ID_AUTOHIDE                     101
#define IDD_APPLICATIONBAR_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_OPTIONS              129
#define IDR_MENU_POPUP                  130
#define ID_DESCRIPTION_FILE             130
#define IDB_BITMAP1                     131
#define IDC_CHECK_ONTOP                 1000
#define IDC_CHECK_AUTOHIDE              1001
#define IDC_RADIO_RIGHT                 1002
#define IDC_RADIO_LEFT                  1003
#define IDC_RADIO_TOP                   1004
#define IDC_RADIO_BOTTOM                1005
#define ID_APPLY                        1006
#define ID_ALWAYSONTOP                  32771
#define ID_FLOATDOCK                    32772
#define ID_LEFTDOCK                     32773
#define ID_TOPDOCK                      32774
#define ID_RIGHTDOCK                    32775
#define ID_BOTTOMDOCK                   32776
#define ID_HASCAPTION                   32777
#define ID_UNREGISTER                   32778
#define ID_REGISTER                     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
