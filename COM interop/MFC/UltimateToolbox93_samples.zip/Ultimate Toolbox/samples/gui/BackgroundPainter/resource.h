//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BackgroundPainter.rc
//
#define IDR_MAINFRAME                   128
#define IDR_BACKGRTYPE                  129
#define ID_DESCRIPTION_FILE             130
#define IDB_WALLPAPER                   130
#define IDD_TEST_DIALOG                 131
#define IDB_LOGO                        132
#define IDD_LOGO_DIALOG                 133
#define IDC_TEXT                        1000
#define IDC_EDITTEXT                    1001
#define IDC_GROUPBOX                    1002
#define IDC_CHECKBOX                    1004
#define IDC_RADIOBTN                    1005
#define IDC_COMBOBOX                    1006
#define IDC_LISTBOX                     1007
#define IDC_SCROLLBARHORZ               1008
#define IDC_SCROLLBARVERT               1009
#define IDC_SPIN                        1010
#define IDC_PROGRESSBAR                 1011
#define IDC_SLIDERBAR                   1012
#define IDC_HOTKEY                      1013
#define IDC_LISTCTRL                    1014
#define IDC_TREECTRL                    1015
#define IDC_TABCTRL                     1016
#define IDC_ANIMATECTRL                 1017
#define IDC_RICHEDITCTRL                1018
#define IDC_DATETIMEPICKER              1019
#define IDC_MONTHCALENDAR               1020
#define IDC_IPADDRESS                   1021
#define IDC_COMBOBOXEX                  1023
#define IDC_IMAGE                       1024
#define IDC_ALIGN_TILE                  1025
#define IDC_ALIGN_STRETCH               1026
#define IDC_ALIGN_TOPLEFT               1027
#define IDC_ALIGN_TOPCENTER             1028
#define IDC_ALIGN_TOPRIGHT              1029
#define IDC_SEPARATOR                   1030
#define IDC_BACKCLR                     1032
#define IDC_ALIGN_CENTERLEFT            1033
#define IDC_ALIGN_CENTER                1034
#define IDC_ALIGN_BOTTOMLEFT            1035
#define IDC_ALIGN_BOTTOMCENTER          1036
#define IDC_ALIGN_CENTERRIGHT           1037
#define IDC_ALIGN_BOTTOMRIGHT           1038
#define IDC_FILENAME                    1039
#define IDC_WEBLINK                     1040
#define ID_VIEW_TESTDIALOG              32771
#define ID_VIEW_LOGODLG                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
