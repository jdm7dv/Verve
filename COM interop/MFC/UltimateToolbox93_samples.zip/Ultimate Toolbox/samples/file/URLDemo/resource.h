//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by URLDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_URLDEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define ID_DESCRIPTION_FILE             129
#define IDD_UNC_LIST                    130
#define IDC_URL_UNC                     1000
#define IDC_PROTOCOL                    1001
#define IDC_PORT                        1002
#define IDC_SERVER                      1003
#define IDC_DIRECTORY                   1004
#define IDC_FILE                        1005
#define IDC_SPLIT_URL                   1006
#define IDC_COMBINE_URL                 1007
#define IDC_SPLIT_UNC                   1008
#define IDC_COMBINE_UNC                 1009
#define IDC_EXTENSION                   1010
#define IDC_BASE_NAME                   1011
#define IDC_TEST                        1012
#define IDC_SHARE                       1013
#define IDC_URL_PART                    1015
#define IDC_INCLUDE_FILES               1016
#define IDC_INCLUDE_DIRS                1017
#define IDC_RECURSIVE                   1018
#define IDC_LIST                        1019
#define IDC_DEPTH_FIRST                 1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
