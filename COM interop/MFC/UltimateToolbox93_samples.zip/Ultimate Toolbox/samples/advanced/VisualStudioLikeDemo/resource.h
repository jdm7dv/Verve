//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VisualStudioLikeDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_VISUALTYPE                  129
#define IDR_TB_WINDOW                   129
#define IDB_IL_3DTABVIEW                130
#define IDB_IL_CLASSVIEW                131
#define IDB_IL_RESOURCEVIEW             132
#define IDB_IL_FILEVIEW                 133
#define IDB_BACKGROUND                  148
#define IDB_SPLASHWINDOW                155
#define IDC_PROGRESS1                   1170
#define IDC_SLIDER1                     1171
#define IDC_HOTKEY2                     1172
#define IDC_DATETIMEPICKER1             1173
#define IDC_COMBOBOXEX2                 1174
#define IDC_IPADDRESS2                  1175
#define ID_FILE_SAVE_ALL                32771
#define ID_EDIT_FIND_IN_FILES           32780
#define ID_VIEW_CUSTOMIZE               32781
#define ID_VIEW_FULL_SCREEN             32782
#define ID_VIEW_OUTPUT                  0xe882
#define ID_TABVIEWBAR                   0xe882
#define ID_VIEW_WORKSPACE               0xe883
#define ID_3DTABVIEWBAR                 0xe883

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1176
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
