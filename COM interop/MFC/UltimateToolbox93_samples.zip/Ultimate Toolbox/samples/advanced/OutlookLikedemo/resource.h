//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Outlook.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDR_MAINFRAME                   128
#define IDR_OUTLOOTYPE                  129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDD_SHBPROPERTIES_DIALOG        132
#define IDR_POPUP_MENU                  133
#define IDI_ICON                        134
#define IDB_BITMAP4                     135
#define IDB_BITMAP5                     136
#define IDC_LIST                        1000
#define IDC_CLRBACK                     1023
#define IDC_TEXTFONT                    1024
#define IDC_HDRCLRBACK                  1026
#define IDC_NAMETEXTFONT                1027
#define IDC_CHECK_APPLYTOEXPANDED       1028
#define IDC_EDIT_GRPMARGIN              1029
#define IDC_HDRFONT                     1030
#define IDC_NAMEHDRFONT                 1031
#define IDC_EDIT_LEFTMARGIN             1032
#define IDC_EDIT_TOPMARGIN              1033
#define IDC_EDIT_RIGHTMARGIN            1034
#define IDC_EDIT_BOTTOMMARGIN           1035
#define IDC_EDIT_SCROLLBTNWIDTH         1036
#define IDC_EDIT_SCROLLBTNHEIGHT        1037
#define IDC_EDIT_HDRHEIGHT              1038
#define ID_NEW_MESSAGE                  32771
#define ID_BACK                         32772
#define ID_FORWARD                      32773
#define ID_UP_ONE_FOLDER                32774
#define ID_TOGGLE_TREE                  32775
#define ID_MOVE_TO_FOLDER               32777
#define ID_DELETE                       32778
#define ID_REPLY                        32779
#define ID_REPLY_TO_ALL                 32780
#define ID_ADDRESS_BOOK                 32782
#define ID_GROUP_BY_BOX                 32783
#define ID_AUTO_PREVIEW                 32784
#define ID_FIND_ITEMS                   32785
#define ID_OFFICE_ASSISTANT             32786
#define IDC_COMBO                       32787
#define ID_FORWARD_MESSAGE              32788
#define ID_POST_IN_FOLDER               32789
#define ID_APPOINTMENT                  32790
#define ID_MEETING_REQUEST              32791
#define ID_CONTACT                      32792
#define ID_TASK                         32793
#define ID_TASK_REQUEST                 32794
#define ID_NOTE                         32795
#define ID_OFFICE_DOCUMENT              32796
#define ID_VIEW_OUTLOOKBAR              32797
#define ID_VIEW_FOLDERVIEW              32798
#define ID_DESCRIPTION_FILE             32799
#define ID_FILE_EXIT                    32799
#define ID_SKIN_CLASSIC                 32800
#define ID_SKIN_OFFICEXP                32801
#define ID_SKIN_OFFICE2003              32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
