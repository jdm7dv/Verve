//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SkinsDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SKINSDTYPE                  129
#define IDB_LARGE                       129
#define IDR_TOOLBAR                     130
#define IDB_TREE                        131
#define IDR_TOOLBAR2                    132
#define IDB_TOOLBAR2_HOT                134
#define IDB_TOOLBAR2_NORMAL             135
#define IDB_TOOLBAR2_DISABLED           136
#define IDB_SMALL                       140
#define IDR_POPUPS                      141
#define IDR_WORKSPACEBAR                143
#define IDR_FOLDERSBAR                  144
#define IDR_PROPERTIESBAR               145
#define IDC_EDIT1                       1000
#define ID_CHECKED                      32772
#define ID_BUTTON32773                  32773
#define ID_BUTTON32774                  32774
#define ID_BUTTON32775                  32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777
#define ID_BUTTON32778                  32778
#define ID_BUTTON32779                  32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_MAIL                         32782
#define ID_FILE_POPUP_ITEM1             32784
#define ID_FILE_POPUP_ITEM2             32785
#define ID_FILE_POPUP_ITEM3             32786
#define ID_CB_EDIT                      32787
#define ID_CB_COMBO                     32788
#define ID_CB_CHECKBOX                  32789
#define ID_CB_PROGRESS                  32790
#define ID_CB_SLIDER                    32791
#define ID_CB_DTP                       32792
#define ID_ITEM1                        32796
#define ID_ITEM2                        32797
#define ID_ITEM3                        32798
#define ID_VIEW_WORKSPACE               32802
#define ID_VIEW_PROPERTIES              32803
#define ID_VIEW_FOLDERS                 32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32805
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
