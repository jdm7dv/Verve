//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define ID_VIEW_ARRANGE                 127
#define IDR_MAINFRAME                   128
#define IDR_FILEEXTYPE                  129
#define ID_VIEW_BACKWARD                129
#define ID_VIEW_FORWARD                 130
#define ID_VIEW_UP                      131
#define IDB_TB_FILE                     132
#define ID_VIEW_PROPERTY                132
#define IDB_TB_FILE_HOT                 133
#define ID_VIEW_TYPE                    133
#define IDR_VIEWTYPE                    133
#define ID_EDIT_DELETE                  134
#define IDB_TB_FILE_DISABLED            134
#define ID_DESCRIPTION_FILE             135

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
