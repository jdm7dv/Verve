//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SystemStateInfo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDR_MAINFRAME                   128
#define ID_DESCRIPTION_FILE             129
#define IDR_TRAYICON_POPUPMENU          129
#define IDD_SSI_DIALOG                  130
#define IDR_APPLICATION_POPUPMENU       130
#define IDB_SHB_LARGE                   131
#define IDB_SHB_SMALL                   132
#define IDB_SYSINFO_TREE_IMAGE          133
#define IDD_SYSINFO_DIALOG              134
#define IDB_BITMAP_REFRESH              135
#define IDD_NETWORKRESOURCES_DIALOG     135
#define IDD_SERVICES_DIALOG             136
#define IDD_APPLICATIONS_DIALOG         137
#define IDB_SPLASH                      138
#define IDD_PROCESSES_DIALOG            138
#define IDB_SERVICES_TREE_IMAGE         139
#define IDB_PROCESSES_TREE_IMAGE        140
#define IDB_LOGO                        141
#define IDC_SHB_TOPICS                  1000
#define IDC_TOPIC                       1003
#define IDC_TREE_ITEMS                  1004
#define IDC_BOTTOMSEPARATOR             1005
#define IDC_BUTTON_REFRESH              1006
#define IDC_RADIO_EXPANDLEVEL           1007
#define IDC_RADIO_EXPANDALL             1008
#define IDC_EDIT_EXPANDLEVEL            1009
#define IDC_SPIN_EXPANDLEVEL            1010
#define IDC_EDIT_MAXLEVEL               1010
#define IDC_RESOURCES_TREE              1011
#define IDC_SEPARATOR1                  1012
#define IDC_CHECK_COMMENTS              1013
#define IDC_CHECK_DISKS                 1014
#define IDC_CHECK_PRINTERS              1015
#define IDC_CHECK_REPORT                1016
#define IDC_COMBO_SCOPE                 1017
#define IDC_SEPARATOR2                  1018
#define IDC_LIST_DETAILS                1020
#define IDC_SPIN_INITIALLEVEL           1021
#define IDC_SPIN_MAXLEVEL               1022
#define IDC_EDIT_INITIALLEVEL           1023
#define IDC_STATIC_INITIALLEVEL         1024
#define IDC_STATIC_MAXLEVEL             1025
#define IDC_TREE_SERVICES               1026
#define IDC_TREE_APPLICATIONS           1027
#define IDC_SHOWPRINTERS                1028
#define IDC_TREE_PROCESSES              1029
#define IDM_APP_SWITCHTO                0x0f00
#define IDM_APP_BRINGTOFRONT            0x0f10
#define IDM_APP_MINIMIZE                0x0f20
#define IDM_APP_RESTORE                 0x0f30
#define IDM_APP_MAXIMIZE                0x0f40
#define IDM_APP_CLOSE                   0x0f50
#define IDM_RESTORE                     32771
#define IDM_CLOSE                       32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
