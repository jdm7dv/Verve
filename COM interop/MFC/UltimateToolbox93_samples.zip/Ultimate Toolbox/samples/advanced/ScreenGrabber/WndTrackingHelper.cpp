// WndTrackingHelper.cpp : implementation file
//

#include "stdafx.h"
#include "ScreenGrabber.h"
#include "WndTrackingHelper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWndTrackingHelper

CWndTrackingHelper::CWndTrackingHelper()
{
}

CWndTrackingHelper::~CWndTrackingHelper()
{
}

BEGIN_MESSAGE_MAP(CWndTrackingHelper, CWnd)
	//{{AFX_MSG_MAP(CWndTrackingHelper)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




