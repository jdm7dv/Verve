#if !defined(AFX_WNDTRACKINGHELPER_H__CA0DF6A2_87B8_11D1_B475_444553540000__INCLUDED_)
#define AFX_WNDTRACKINGHELPER_H__CA0DF6A2_87B8_11D1_B475_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// WndTrackingHelper.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWndTrackingHelper window

class CWndTrackingHelper : public CWnd
{
// Construction
public:
	CWndTrackingHelper();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWndTrackingHelper)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWndTrackingHelper();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWndTrackingHelper)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WNDTRACKINGHELPER_H__CA0DF6A2_87B8_11D1_B475_444553540000__INCLUDED_)
