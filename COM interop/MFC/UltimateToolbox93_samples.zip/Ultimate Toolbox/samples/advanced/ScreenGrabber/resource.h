//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScreenGrabber.rc
//
#define ID_MIN_INITIAL_DELAY            1
#define ID_MIN_WIDTH                    1
#define ID_MIN_HEIGHT                   1
#define IDM_ABOUTBOX                    0x0010
#define ID_MAX_INITIAL_DELAY            60
#define IDS_ABOUTBOX                    101
#define IDD_PROPPAGE_DESTINATION        102
#define IDR_MAINFRAME                   128
#define ID_DESCRIPTION_FILE             129
#define IDD_PROPPAGE_ACTIVATION         129
#define IDD_PROPPAGE_SOURCE             130
#define IDD_PROPPAGE_IMAGE              132
#define IDD_PROPPAGE_FILE               133
#define IDD_PROPPAGE_PREFERENCES        134
#define IDR_POPUPMENU                   134
#define IDM_MINIMIZE                    0x00f0
#define SIZE_ERROR_BUF                  255
#define IDC_COMBO_HOT_KEY               1000
#define IDC_EDIT_INITIAL_DELAY          1001
#define IDC_SPIN_INITIAL_DELAY          1002
#define IDC_STATIC_HOT_KEY              1004
#define IDC_RADIO_CURRENT_WINDOW        1006
#define IDC_RADIO_CLIENT_WINDOW         1007
#define IDC_CHECK_FILE                  1007
#define IDC_RADIO_FULL_SCREEN           1008
#define IDC_CHECK_RESIZE                1008
#define IDC_CHECK_CLIPBOARD             1008
#define IDC_RADIO_RECT_AREA             1009
#define IDC_STATIC_WIDTH                1009
#define IDC_STATIC_HEIGHT               1010
#define IDC_EDIT_WIDTH                  1011
#define IDC_SPIN_WIDTH                  1012
#define IDC_EDIT_HEIGHT                 1013
#define IDC_SPIN_HEIGHT                 1014
#define IDC_CHECK_MAINTAIN_RATIO        1015
#define IDC_STATIC_FILE_NAME            1016
#define IDC_STATIC_FILE_TYPE            1017
#define IDC_CHECK_AUTOMATIC_NAMING      1018
#define IDC_COMBO_FILE_NAME             1019
#define IDC_COMBO_FILE_TYPE             1020
#define IDC_BUTTON_CAPTURE_DIR          1021
#define IDC_STATIC_CAPTURE_DIR          1022
#define IDC_CHECK_HIDE_ICON             1023
#define IDC_CHECK_NOTIFY_END            1024
#define IDC_CHECK_INITIAL_DELAY         1025
#define IDC_STATIC_TIMING               1026
#define IDC_STATIC_AREA                 1027
#define IDC_STATIC_DIR                  1028
#define IDC_STATIC_RESIZING             1029
#define IDC_STATIC_SETTINGS             1030
#define IDC_STATIC_DESTINATION          1031
#define ID_TIMER_CAPTURE_DELAY          1234
#define ID_HOTKEY                       0x1234
#define ID_MAX_WIDTH                    16384
#define ID_MAX_HEIGHT                   16384
#define ID_OPEN                         32771
#define ID_ABOUT                        32772
#define ID_CLOSE                        32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           114
#endif
#endif
