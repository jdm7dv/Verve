//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Serial.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SERIALTYPE                  129
#define IDD_TIMEOUT                     130
#define IDD_TRANSFER                    132
#define IDC_TIMEOUT_RX                  1000
#define IDC_TIMEOUT_TX                  1001
#define IDC_TRANSFER_PROGRESS           1004
#define IDC_TRANSFER_TEXT               1005
#define IDM_SERIAL_SETUP                32771
#define IDM_CONFIG_LOAD                 32772
#define IDM_CONFIG_SAVE                 32773
#define IDM_TIMEOUT                     32774
#define IDM_FILE_READ                   32776
#define IDM_FILE_WRITE                  32777
#define IDM_PURGE_RX                    32780
#define IDM_PURGE_TX                    32781
#define IDM_OPEN                        32782
#define IDM_CLOSE                       32783
#define IDM_CONNECT                     32785
#define IDM_DISCONNECT                  32786
#define IDM_RECEIVE                     32788
#define IDM_SEND                        32789
#define IDM_SET_TIMEOUT                 32790
#define IDM_OPTIONS_RECEIVE             32791
#define ID_DESCRIPTION_FILE             61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
