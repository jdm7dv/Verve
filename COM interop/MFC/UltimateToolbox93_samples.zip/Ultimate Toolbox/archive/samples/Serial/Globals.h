#ifndef __GLOBALS_H__INCLUDED
#define __GLOBALS_H__INCLUDED

#include <direct.h>

CString GetAppDir();
void PumpMessages();

#endif