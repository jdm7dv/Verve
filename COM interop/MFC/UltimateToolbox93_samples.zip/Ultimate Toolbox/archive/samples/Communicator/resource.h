//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Communicator.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_COMMUNICATOR_FORM           101
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_COMMTYPE                    129
#define IDD_SEND_DATA                   130
#define IDS_INVALID_VALUE               130
#define IDS_FAILED_LISTEN               131
#define IDS_FAILED_CONNECT              132
#define IDC_LOCAL_ADDRESS               1000
#define IDC_LOCAL_PORT                  1001
#define IDC_CLIENT_ADDRESSES            1002
#define IDC_SEND_CLIENT                 1003
#define IDC_DISCONNECT_CLIENT           1004
#define IDC_RECEIVED_DATA               1005
#define IDC_LISTEN                      1006
#define IDC_CANCEL                      1007
#define IDC_SHUTDOWN                    1008
#define IDC_EMPTY                       1009
#define IDC_LOCAL_ADDRESS_LABEL         1009
#define IDC_NULL                        1010
#define IDC_LOCAL_PORT_LABEL            1010
#define IDC_BOOL                        1011
#define IDC_CLIENT_ADDRESSES_LABEL      1011
#define IDC_UI1                         1012
#define IDC_REMOTE_PORT                 1012
#define IDC_I2                          1013
#define IDC_CONNECT_SERVER              1013
#define IDC_I4                          1014
#define IDC_DISCONNECT_SERVER           1014
#define IDC_CY                          1015
#define IDC_SEND_SERVER                 1015
#define IDC_R4                          1016
#define IDC_REMOTE_ADDRESS              1016
#define IDC_R8                          1017
#define IDC_SPY                         1017
#define IDC_BSTR                        1018
#define IDC_REMOTE_ADDRESS_LABEL        1018
#define IDC_DATE                        1019
#define IDC_REMOTE_PORT_LABEL           1019
#define IDC_ERROR                       1020
#define IDC_SERVER_GROUP                1020
#define IDC_VALUE                       1021
#define IDC_CLIENT_GROUP                1021
#define IDC_ADD                         1022
#define IDC_LIST                        1023
#define IDC_BINARY                      1024
#define IDC_BROWSE                      1025
#define ID_DESCRIPTION_FILE             61216

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
