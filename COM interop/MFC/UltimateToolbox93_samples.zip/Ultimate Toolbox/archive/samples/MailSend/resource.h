//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MailSend.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_MAILSEND_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_SEND_MAIL                   1002
#define IDC_ABOUT                       1003
#define IDC_PROFILE                     1004
#define IDC_PASSWORD                    1005
#define IDC_ADDRESS                     1006
#define IDC_SUBJECT                     1007
#define IDC_LIST_ATTACHMENTS            1008
#define IDC_CONTENT                     1009
#define IDC_BUTTON_ADDATTACHMENT        1010
#define IDC_BUTTON_REMOVEATTACHMENT     1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
