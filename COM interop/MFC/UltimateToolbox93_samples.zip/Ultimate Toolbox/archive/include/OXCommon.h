//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OXCommon.rc
//
#define psh14                           0x040d
#define chx1                            0x0410
#define stc1                            0x0440
#define stc2                            0x0441
#define stc3                            0x0442
#define stc4                            0x0443
#define stc32                           0x045f
#define lst1                            0x0460
#define lst2                            0x0461
#define cmb1                            0x0470
#define cmb2                            0x0471
#define edt1                            0x0480
#define IDC_PREVIEW_WND                 23080
#define IDC_PREVIEW_FRAME               23081
#define IDC_PREVIEW                     23082

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        23083
#define _APS_NEXT_COMMAND_VALUE         53080
#define _APS_NEXT_CONTROL_VALUE         23080
#define _APS_NEXT_SYMED_VALUE           23080
#endif
#endif
